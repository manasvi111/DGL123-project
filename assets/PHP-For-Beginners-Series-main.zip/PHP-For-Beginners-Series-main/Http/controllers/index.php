<?php

view("index.view.php", [
    'heading' => 'Home',
]);